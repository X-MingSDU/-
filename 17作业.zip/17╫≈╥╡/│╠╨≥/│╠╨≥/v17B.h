#ifndef _XYV17B_H_
#define _XYV17B_H_
void uart_init();
void uart_tx_command(unsigned int);
#endif

